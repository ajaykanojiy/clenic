<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<div id="error-wrapper" class="wrapper">
        <div class="background"></div>
        <div class="pagewidth">
            <div class="text">
                <p class="p1">404</p>
                <p class="p2">error</p>
                <input type="text" placeholder="KEYWORD SEARCH">
                <img src="<?php echo base_url() ?>frontend/assets/img/zoom_error.png" id="zoom">
            </div>

        </div>
    </div>